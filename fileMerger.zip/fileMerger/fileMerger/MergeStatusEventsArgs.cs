﻿// MergeStatusEventArgs.cs
using System;

namespace FileMerger
{
    public class MergeStatusEventArgs : EventArgs
    {
        // Ensure that the Status enumeration is public or has the same access modifier as the class
        public Status Status { get; set; }

        public int FileIndex { get; set; }
        public int TotalFiles { get; set; }
        public string FileName { get; set; }
        public int ErrorDetailCode { get; set; }

        public MergeStatusEventArgs(Status status, int index = 0, string filename = "", int errorDetailCode = 0)
        {
            Status = status;
            FileIndex = index;
            FileName = filename;
            ErrorDetailCode = errorDetailCode;
        }
    }
}
