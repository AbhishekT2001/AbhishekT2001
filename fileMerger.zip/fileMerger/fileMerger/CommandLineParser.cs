﻿// CommandLineParser.cs
using System;

namespace FileMerger
{
    class CommandLineParser
    {
        public static bool ValidateArgs(string[] args)
        {
            return args.Length == 2;
        }
    }
}
