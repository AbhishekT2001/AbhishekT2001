﻿// Enums.cs
namespace FileMerger
{
    public enum ErrorType
    {
        SourceFolderNotExist,
        FileAlreadyExists
    }

    public enum Status
    {
        Start,
        InProgress,
        Success,
        Failed
    }
}
