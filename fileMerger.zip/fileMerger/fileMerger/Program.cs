﻿// Program.cs
using System;

namespace FileMerger
{
    class Program
    {
        static void Main(string[] args)
        {
            // Validate command line arguments
            if (!CommandLineParser.ValidateArgs(args))
            {
                PrintUsage();
                return;
            }

            string inputFolder = args[0];
            string outputFile = args[1];

            // Instantiate file merger
            FileMerger merger = new FileMerger(inputFolder, outputFile);

            // Register callback
            merger.MergeStatusChanged += MergeCallback.OnStatusChanged;

            // Start merge
            try
            {
                merger.MergeFiles();
            }
            catch (FileMergeException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        static void PrintUsage()
        {
            Console.WriteLine("Error: Invalid input. Program usage is as below");
            Console.WriteLine("[FileMerger.exe] [Source folder path] [Merged file path]");
        }
    }
}
