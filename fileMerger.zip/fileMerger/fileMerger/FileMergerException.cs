﻿// FileMergeException.cs
using System;

namespace FileMerger
{
    class FileMergeException : Exception
    {
        public ErrorType ErrorType { get; set; }
        public int ErrorDetailCode { get; set; }

        public FileMergeException(ErrorType type, int code, string message) : base(message)
        {
            ErrorType = type;
            ErrorDetailCode = code;
        }
    }
}
