﻿namespace FileMerger
{
    class MergeCallback
    {
        public static void OnStatusChanged(object sender, MergeStatusEventArgs args)
        {
            switch (args.Status)
            {
                case Status.Start:
                    Console.WriteLine("File merge started");
                    break;

                case Status.InProgress:
                    Console.WriteLine("[{0}/{1}]: {2} merged", args.FileIndex, args.TotalFiles, args.FileName);
                    break;

                case Status.Success:
                    Console.WriteLine("File merge completed (Success)");
                    break;

                case Status.Failed:
                    Console.WriteLine("File merge failed (Error: {0})", args.ErrorDetailCode);
                    break;
            }
        }
    }
}
