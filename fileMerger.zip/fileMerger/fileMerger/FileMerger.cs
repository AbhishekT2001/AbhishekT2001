﻿// FileMerger.cs
using System;

namespace FileMerger
{
    // Define the delegate directly in the FileMerger class
    public delegate void MergeStatusChangedEventHandler(object sender, MergeStatusEventArgs args);

    class FileMerger
    {
        public event MergeStatusChangedEventHandler MergeStatusChanged;

        string inputFolder;
        string outputFile;

        public FileMerger(string input, string output)
        {
            inputFolder = input;
            outputFile = output;
        }

        public void MergeFiles()
        {
            ValidatePaths();

            int count = 0;

            using (Stream output = File.OpenWrite(outputFile))
            {
                foreach (string file in Directory.GetFiles(inputFolder))
                {
                    using (Stream input = File.OpenRead(file))
                    {
                        input.CopyTo(output);
                    }

                    count++;
                    MergeStatusChanged?.Invoke(this, new MergeStatusEventArgs(Status.InProgress, count, file));
                }
            }

            MergeStatusChanged?.Invoke(this, new MergeStatusEventArgs(Status.Success));
        }

        private void ValidatePaths()
        {
            if (!Directory.Exists(inputFolder))
            {
                throw new FileMergeException(ErrorType.SourceFolderNotExist, 1000, "Source folder does not exist");
            }

            if (File.Exists(outputFile))
            {
                throw new FileMergeException(ErrorType.FileAlreadyExists, 1001, "Merged file already exists");
            }
        }
    }
}
