﻿namespace FileMerger
{
    public delegate void MergeStatusChangedEventHandler(object sender, MergeStatusEventArgs args);

    public class FileMerger
    {
        public event MergeStatusChangedEventHandler MergeStatusChanged;

        string inputFolder;
        string outputFile;

        public FileMerger(string input, string output = null)
        {
            inputFolder = input;

            // If the output file is not provided or is empty/whitespace, use the input folder path
            outputFile = string.IsNullOrWhiteSpace(output) ? Path
                .Combine(Path.GetDirectoryName(input), Path
                .GetFileNameWithoutExtension(input) + ".mrg") : output;
        }

        public void MergeFiles()
        {
            // Check if the source folder exists
            ValidateSourceFolder();

            // Check if there are any files in the source folder
            string[] files = Directory.GetFiles(inputFolder);
            if (files.Length == 0)
            {
                OnMergeStatusChanged(new MergeStatusEventArgs(Status.Failed, 0, "Source folder does not contain any files"));
                return;
            }

            // Check if the merged file already exists
            if (File.Exists(outputFile))
            {
                OnMergeStatusChanged(new MergeStatusEventArgs(Status.Failed, 0, "Merged file already exists"));
                return;
            }

            int count = 0;
            int totalFiles = files.Length;

            using (Stream output = File.OpenWrite(outputFile))
            {
                foreach (string file in files)
                {
                    using (Stream input = File.OpenRead(file))
                    {
                        input.CopyTo(output);
                    }
                    count++;
                    OnMergeStatusChanged(new MergeStatusEventArgs(Status.InProgress, count, file , totalFiles));
                }
            }

            OnMergeStatusChanged(new MergeStatusEventArgs(Status.Success, totalFiles));
        }

        private void ValidateSourceFolder()
        {
            if (!Directory.Exists(inputFolder))
            {
                OnMergeStatusChanged(new MergeStatusEventArgs(Status.Failed, 0, "Source folder does not exist"));
                throw new FileMergeException(ErrorType.SourceFolderNotExist, 1000, "Source folder does not exist");
            }
        }

        private void OnMergeStatusChanged(MergeStatusEventArgs args)
        {
            MergeStatusChanged?.Invoke(this, args);
        }
    }
}
