﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private FileCopyManager fileCopyManager;
        public Form1()
        {
            fileCopyManager = new FileCopyManager();
            InitializeComponent();
            InitializeDataGridView();
            fileCopyManager = new FileCopyManager();
            fileCopyManager.OnProgressUpdate += UpdateProgress;
            //fileCopyManager.OnCopyComplete += ShowCompletionMessage;
        }

        private void InitializeDataGridView()
        {
            // Assuming you have a DataGridView named dataGridView in your form
           // dataGridView1.AutoGenerateColumns = true;
           // dataGridView1.DataSource = fileCopyManager.GetProgressDataTable();
        }

        private void BtnSelectSource_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Multiselect = true;
            openFileDialog.Filter = "All Files|*.*";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                // Get selected file names and display in the source TextBox
                string[] selectedFiles = openFileDialog.FileNames;
                string filesText = string.Join(", ", selectedFiles);
                textBox1.Text = filesText;
            }
        }

        private void BtnSelectDestination_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();

            if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                // Get selected folder path and display it in the destination TextBox
                string selectedFolder = folderBrowserDialog.SelectedPath;
                textBox2.Text = selectedFolder;
            }
        }

        private void BtnAddToCopy_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();

            string[] selectedFiles = textBox1.Text.Split(new[] { ", " }, StringSplitOptions.RemoveEmptyEntries);
            string destinationPath = textBox2.Text;

            if (selectedFiles.Length > 0 && Directory.Exists(destinationPath))
            {
                int threadCount = 5; // Default number of threads

                fileCopyManager.CopyFilesWithMultithreading(selectedFiles, destinationPath);
            }
            else
            {
                MessageBox.Show("Please select valid source files and a destination folder.");
            }
        }

        private void UpdateProgress(int filesCopied, int totalFiles)
        {
            // Update UI with progress information
            // This could include updating a progress bar, labels, or any other UI elements
            Invoke((Action)(() =>
            {
                //lblProgress.Text = $"{filesCopied} out of {totalFiles} files copied";
                DataTable progressDataTable = fileCopyManager.GetProgressDataTable();
                dataGridView1.DataSource = progressDataTable;
                dataGridView1.Refresh(); // Refresh the DataGridView to reflect changes
            }));
        }

    }
}
