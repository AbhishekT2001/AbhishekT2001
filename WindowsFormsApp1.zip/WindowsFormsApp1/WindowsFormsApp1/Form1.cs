﻿using System;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private FileCopyManager fileCopyManager;
        private CancellationTokenSource cts;
        private BindingList<ProgressData> progressList = new BindingList<ProgressData>();

        public Form1()
        {
            InitializeComponent();
            cts = new CancellationTokenSource();
            fileCopyManager = new FileCopyManager();
            fileCopyManager.ProgressChanged += UpdateProgress;
            //fileCopyManager.ErrorOccurred += UpdateError;
            InitializeComponent();
            dataGridView1.DataSource = progressList;

        }

        private void BtnSelectSource_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Multiselect = true;
            openFileDialog.Filter = "All Files|*.*";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                // Get selected file names and display in the source TextBox
                string[] selectedFiles = openFileDialog.FileNames;
                string filesText = string.Join(", ", selectedFiles);
                textBox1.Text = filesText;
            }
        }

        private void BtnSelectDestination_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();

            if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                // Get selected folder path and display it in the destination TextBox
                string selectedFolder = folderBrowserDialog.SelectedPath;
                textBox2.Text = selectedFolder;
            }
        }

        private void BtnAddToCopy_Click(object sender, EventArgs e)
        {
            // Clear the DataGridView
            dataGridView1.Rows.Clear();

            // Get selected files and destination path
            string[] selectedFiles = textBox1.Text.Split(new[] { ", " }, StringSplitOptions.RemoveEmptyEntries);
            string destinationPath = textBox2.Text;

            // Check if selected files are valid and destination folder exists
            if (selectedFiles.Length > 0 && Directory.Exists(destinationPath))
            {
                // Start file copy process in a separate thread
                Thread copyThread = new Thread(() => fileCopyManager.CopyFiles(selectedFiles, destinationPath));
                copyThread.Start();
            }
            else
            {
                MessageBox.Show("Please select valid source files and a destination folder.");
            }
        }


        private void UpdateProgress(string source, string destination, int threadIndex, int percentCompletion, string error)
        {
            if (dataGridView1.InvokeRequired)
            {
                dataGridView1.Invoke(new Action(() =>
                {
                    var existingRow = progressList.FirstOrDefault(row => row.Source == source);
                    if (existingRow != null)
                    {
                        // Update existing row
                        existingRow.ThreadIndex = threadIndex;
                        existingRow.PercentCompletion = percentCompletion;
                        existingRow.Error = error;
                    }
                    else
                    {
                        // Add new row
                        progressList.Add(new ProgressData
                        {
                            Source = source,
                            Destination = destination,
                            ThreadIndex = threadIndex,
                            PercentCompletion = percentCompletion,
                            Error = error
                        });
                    }
                }));
            }
            else
            {
                // Handle UI updates on the main thread if invoking is not required
                // Add/update rows in the DataGridView based on the progress of each source file
                // Use source, destination, threadIndex, percentCompletion, and error as needed
            }
        }



        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void BtnCancelAll_Click(object sender, EventArgs e)
        {
            cts.Cancel();
        }

        public class ProgressData
        {
            public string Source { get; set; }
            public string Destination { get; set; }
            public int ThreadIndex { get; set; }
            public int PercentCompletion { get; set; }
            public string Error { get; set; }
        }

    }
}
