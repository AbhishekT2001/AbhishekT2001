﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.BtnSelectSource = new System.Windows.Forms.Button();
            this.BtnSelectDestination = new System.Windows.Forms.Button();
            this.BtnAddToCopy = new System.Windows.Forms.Button();
            this.BtnCancelAll = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.progressDataBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sourceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.destinationDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.threadIndexDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.percentCompletionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.errorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.progressDataBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(70, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "Source";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(48, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "Destination";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(132, 23);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(910, 22);
            this.textBox1.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(132, 65);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(910, 22);
            this.textBox2.TabIndex = 3;
            // 
            // BtnSelectSource
            // 
            this.BtnSelectSource.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSelectSource.Location = new System.Drawing.Point(1048, 20);
            this.BtnSelectSource.Name = "BtnSelectSource";
            this.BtnSelectSource.Size = new System.Drawing.Size(75, 23);
            this.BtnSelectSource.TabIndex = 4;
            this.BtnSelectSource.Text = "Browse";
            this.BtnSelectSource.UseVisualStyleBackColor = true;
            this.BtnSelectSource.Click += new System.EventHandler(this.BtnSelectSource_Click);
            // 
            // BtnSelectDestination
            // 
            this.BtnSelectDestination.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSelectDestination.Location = new System.Drawing.Point(1048, 65);
            this.BtnSelectDestination.Name = "BtnSelectDestination";
            this.BtnSelectDestination.Size = new System.Drawing.Size(75, 23);
            this.BtnSelectDestination.TabIndex = 5;
            this.BtnSelectDestination.Text = "Browse";
            this.BtnSelectDestination.UseVisualStyleBackColor = true;
            this.BtnSelectDestination.Click += new System.EventHandler(this.BtnSelectDestination_Click);
            // 
            // BtnAddToCopy
            // 
            this.BtnAddToCopy.BackColor = System.Drawing.SystemColors.Highlight;
            this.BtnAddToCopy.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAddToCopy.Location = new System.Drawing.Point(51, 111);
            this.BtnAddToCopy.Name = "BtnAddToCopy";
            this.BtnAddToCopy.Size = new System.Drawing.Size(496, 32);
            this.BtnAddToCopy.TabIndex = 6;
            this.BtnAddToCopy.Text = "Add to Copy";
            this.BtnAddToCopy.UseVisualStyleBackColor = false;
            this.BtnAddToCopy.Click += new System.EventHandler(this.BtnAddToCopy_Click);
            // 
            // BtnCancelAll
            // 
            this.BtnCancelAll.BackColor = System.Drawing.SystemColors.GrayText;
            this.BtnCancelAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCancelAll.Location = new System.Drawing.Point(553, 111);
            this.BtnCancelAll.Name = "BtnCancelAll";
            this.BtnCancelAll.Size = new System.Drawing.Size(509, 32);
            this.BtnCancelAll.TabIndex = 7;
            this.BtnCancelAll.Text = "Cancel All";
            this.BtnCancelAll.UseVisualStyleBackColor = false;
            this.BtnCancelAll.Click += new System.EventHandler(this.BtnCancelAll_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.sourceDataGridViewTextBoxColumn,
            this.destinationDataGridViewTextBoxColumn,
            this.threadIndexDataGridViewTextBoxColumn,
            this.percentCompletionDataGridViewTextBoxColumn,
            this.errorDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.progressDataBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(51, 149);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(1011, 407);
            this.dataGridView1.TabIndex = 8;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // progressDataBindingSource
            // 
            this.progressDataBindingSource.DataSource = typeof(WindowsFormsApp1.Form1.ProgressData);
            // 
            // sourceDataGridViewTextBoxColumn
            // 
            this.sourceDataGridViewTextBoxColumn.DataPropertyName = "Source";
            this.sourceDataGridViewTextBoxColumn.HeaderText = "Source";
            this.sourceDataGridViewTextBoxColumn.Name = "sourceDataGridViewTextBoxColumn";
            this.sourceDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // destinationDataGridViewTextBoxColumn
            // 
            this.destinationDataGridViewTextBoxColumn.DataPropertyName = "Destination";
            this.destinationDataGridViewTextBoxColumn.HeaderText = "Destination";
            this.destinationDataGridViewTextBoxColumn.Name = "destinationDataGridViewTextBoxColumn";
            this.destinationDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // threadIndexDataGridViewTextBoxColumn
            // 
            this.threadIndexDataGridViewTextBoxColumn.DataPropertyName = "ThreadIndex";
            this.threadIndexDataGridViewTextBoxColumn.HeaderText = "ThreadIndex";
            this.threadIndexDataGridViewTextBoxColumn.Name = "threadIndexDataGridViewTextBoxColumn";
            this.threadIndexDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // percentCompletionDataGridViewTextBoxColumn
            // 
            this.percentCompletionDataGridViewTextBoxColumn.DataPropertyName = "PercentCompletion";
            this.percentCompletionDataGridViewTextBoxColumn.HeaderText = "PercentCompletion";
            this.percentCompletionDataGridViewTextBoxColumn.Name = "percentCompletionDataGridViewTextBoxColumn";
            this.percentCompletionDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // errorDataGridViewTextBoxColumn
            // 
            this.errorDataGridViewTextBoxColumn.DataPropertyName = "Error";
            this.errorDataGridViewTextBoxColumn.HeaderText = "Error";
            this.errorDataGridViewTextBoxColumn.Name = "errorDataGridViewTextBoxColumn";
            this.errorDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 701);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.BtnCancelAll);
            this.Controls.Add(this.BtnAddToCopy);
            this.Controls.Add(this.BtnSelectDestination);
            this.Controls.Add(this.BtnSelectSource);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.MinimumSize = new System.Drawing.Size(1200, 718);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.progressDataBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button BtnSelectSource;
        private System.Windows.Forms.Button BtnSelectDestination;
        private System.Windows.Forms.Button BtnAddToCopy;
        private System.Windows.Forms.Button BtnCancelAll;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn threadIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sourcePathDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn destinationPathDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn progressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sourceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn destinationDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn threadIndexDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn percentCompletionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn errorDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource progressDataBindingSource;
    }
}

