﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.BtnSelectSource = new System.Windows.Forms.Button();
            this.BtnSelectDestination = new System.Windows.Forms.Button();
            this.BtnAddToCopy = new System.Windows.Forms.Button();
            this.BtnCancelAll = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.fileaCopyManagerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fileaCopyManagerBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Source";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Destination";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(88, 20);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(614, 20);
            this.textBox1.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(88, 46);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(614, 20);
            this.textBox2.TabIndex = 3;
            // 
            // BtnSelectSource
            // 
            this.BtnSelectSource.Location = new System.Drawing.Point(708, 18);
            this.BtnSelectSource.Name = "BtnSelectSource";
            this.BtnSelectSource.Size = new System.Drawing.Size(75, 23);
            this.BtnSelectSource.TabIndex = 4;
            this.BtnSelectSource.Text = "button1";
            this.BtnSelectSource.UseVisualStyleBackColor = true;
            this.BtnSelectSource.Click += new System.EventHandler(this.BtnSelectSource_Click);
            // 
            // BtnSelectDestination
            // 
            this.BtnSelectDestination.Location = new System.Drawing.Point(708, 43);
            this.BtnSelectDestination.Name = "BtnSelectDestination";
            this.BtnSelectDestination.Size = new System.Drawing.Size(75, 23);
            this.BtnSelectDestination.TabIndex = 5;
            this.BtnSelectDestination.Text = "button2";
            this.BtnSelectDestination.UseVisualStyleBackColor = true;
            this.BtnSelectDestination.Click += new System.EventHandler(this.BtnSelectDestination_Click);
            // 
            // BtnAddToCopy
            // 
            this.BtnAddToCopy.Location = new System.Drawing.Point(15, 93);
            this.BtnAddToCopy.Name = "BtnAddToCopy";
            this.BtnAddToCopy.Size = new System.Drawing.Size(336, 23);
            this.BtnAddToCopy.TabIndex = 6;
            this.BtnAddToCopy.Text = "button1";
            this.BtnAddToCopy.UseVisualStyleBackColor = true;
            this.BtnAddToCopy.Click += new System.EventHandler(this.BtnAddToCopy_Click);
            // 
            // BtnCancelAll
            // 
            this.BtnCancelAll.Location = new System.Drawing.Point(357, 93);
            this.BtnCancelAll.Name = "BtnCancelAll";
            this.BtnCancelAll.Size = new System.Drawing.Size(336, 23);
            this.BtnCancelAll.TabIndex = 7;
            this.BtnCancelAll.Text = "button2";
            this.BtnCancelAll.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.DataSource = this.fileaCopyManagerBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(15, 141);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(768, 150);
            this.dataGridView1.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.BtnCancelAll);
            this.Controls.Add(this.BtnAddToCopy);
            this.Controls.Add(this.BtnSelectDestination);
            this.Controls.Add(this.BtnSelectSource);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fileaCopyManagerBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button BtnSelectSource;
        private System.Windows.Forms.Button BtnSelectDestination;
        private System.Windows.Forms.Button BtnAddToCopy;
        private System.Windows.Forms.Button BtnCancelAll;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource fileaCopyManagerBindingSource;
    }
}

