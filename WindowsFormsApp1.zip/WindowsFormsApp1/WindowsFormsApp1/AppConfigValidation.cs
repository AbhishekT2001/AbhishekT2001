﻿using System.Configuration;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Authentication;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public class AppConfigValidation
    {
        public static void AppConfig()
        {
            var CopythreadCount = ConfigurationManager.AppSettings["CopyThreadCount"];
            int threadCount = int.Parse(CopythreadCount);

            if (!File.Exists("C:\\Users\\admin\\source\\repos\\WindowsFormsApp1\\WindowsFormsApp1\\App.config"))
            {
                MessageBox.Show("App config file not found \n (Using the default thread 5)");
            }

            if(threadCount > 100)
            {
                MessageBox.Show("The thread count is more than the default thread count 100 \n (Max Thread count 100 is used)");
            }
        }
    }
}
