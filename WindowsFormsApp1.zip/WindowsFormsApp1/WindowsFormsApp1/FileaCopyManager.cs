﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading;

public class FileCopyManager
{
    private object lockObject = new object();
    private List<FileCopyTask> copyTasks = new List<FileCopyTask>();

    public event Action<int, int> OnProgressUpdate;
    public event Action<string> OnCopyComplete;

    public DataTable GetProgressDataTable()
    {
        DataTable progressTable = new DataTable();
        progressTable.Columns.Add("ThreadID", typeof(int));
        progressTable.Columns.Add("SourcePath", typeof(string));
        progressTable.Columns.Add("DestinationPath", typeof(string));
        progressTable.Columns.Add("Status", typeof(string));
        progressTable.Columns.Add("Progress", typeof(int));
        progressTable.PrimaryKey = new DataColumn[] { progressTable.Columns["ThreadID"] };

        lock (lockObject)
        {
            foreach (FileCopyTask task in copyTasks)
            {
                DataRow row = progressTable.NewRow();
                row["ThreadID"] = task.ThreadID;
                row["SourcePath"] = task.SourcePath;
                row["DestinationPath"] = task.DestinationPath;
                row["Status"] = task.Status;
                row["Progress"] = task.Progress;
                progressTable.Rows.Add(row);
            }
        }

        return progressTable;
    }

    public void CopyFilesWithMultithreading(string[] sourceFiles, string destinationFolder)
    {
        for (int i = 0; i < sourceFiles.Length; i++)
        {
            FileCopyTask task = new FileCopyTask(i, sourceFiles[i], destinationFolder);
            ThreadPool.QueueUserWorkItem(state => CopyFile(task));
            copyTasks.Add(task);
        }
    }

    private void CopyFile(FileCopyTask task)
    {
        try
        {
            string fileName = Path.GetFileName(task.SourcePath);
            string destinationFilePath = Path.Combine(task.DestinationPath, fileName);

            File.Copy(task.SourcePath, destinationFilePath, true); // Set overwrite to true to replace existing files

            lock (lockObject)
            {
                task.Status = "Completed";
                task.Progress = 100;

                // Notify about the progress
                OnProgressUpdate?.Invoke(copyTasks.Count(t => t.Status == "Completed"), copyTasks.Count);

                if (copyTasks.All(t => t.Status == "Completed"))
                {
                    // Notify when all files are copied
                    OnCopyComplete?.Invoke("File copy completed.");
                }
            }
        }
        catch (Exception ex)
        {
            // Handle exceptions (e.g., file in use, permissions issues)
            Console.WriteLine($"Error copying file {task.SourcePath}: {ex.Message}");
        }
    }
}

public class FileCopyTask
{
    public int ThreadID { get; }
    public string SourcePath { get; }
    public string DestinationPath { get; }
    public string Status { get; set; }
    public int Progress { get; set; }

    public FileCopyTask(int threadID, string sourcePath, string destinationPath)
    {
        ThreadID = threadID;
        SourcePath = sourcePath;
        DestinationPath = destinationPath;
        Status = "Running";
        Progress = 0;
    }
}
