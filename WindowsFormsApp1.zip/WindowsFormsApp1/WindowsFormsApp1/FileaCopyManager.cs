﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Threading;

class FileCopyManager
{
    private readonly int copyThreadCount;
        public event Action<string, string, int, int, string> ProgressChanged;
        public event Action<string, string, int, string> ErrorOccurred;

    public void CopyFiles(IEnumerable<string> sourceFiles, string destinationDirectory)
    {
        foreach (string sourceFile in sourceFiles)
        {
            Thread copyThread = new Thread(() => CopyFile(sourceFile, destinationDirectory));
            copyThread.Start();
        }
    }

    private void CopyFile(string sourceFile, string destinationDirectory)
    {
        try
        {
            string destinationFile = Path.Combine(destinationDirectory, Path.GetFileName(sourceFile));

            File.Copy(sourceFile, destinationFile, true); // Overwrite existing files

            ProgressChanged?.Invoke(sourceFile, destinationFile, Thread.CurrentThread.ManagedThreadId, 100, null);
        }
        catch (Exception ex)
        {
            ErrorOccurred?.Invoke(sourceFile, destinationDirectory, Thread.CurrentThread.ManagedThreadId, ex.Message);
        }
    }
}
