﻿using System.Collections.Generic;
using System;

public class PrintDevice
{
    public static void printDevice(Dictionary<string, Device> deviceDictionary)
    {
        foreach (var kvp in deviceDictionary)
        {
            Console.WriteLine($"SrNo: {kvp.Key}");
            Console.WriteLine($"Address: {kvp.Value.Address}");
            Console.WriteLine($"Modelname: {kvp.Value.Modelname}");
            Console.WriteLine($"devName: {kvp.Value.devName}");
            Console.WriteLine($"Type: {kvp.Value.type}");
            Console.WriteLine($"CommSetting: ");
            Console.WriteLine($"   PortNo: {kvp.Value.commSetting.portNo}");
            Console.WriteLine($"   UseSSl: {kvp.Value.commSetting.useSSl}");
            Console.WriteLine($"   Password: {kvp.Value.commSetting.password}");
            Console.WriteLine();
        }
    }
}