﻿using System.Collections.Generic;
using System.Xml.Serialization;

[XmlRoot("dev")]
public class Device
{
    [XmlAttribute("SrNo")]
    public string SrNo { get; set; }
    public string Address { get; set; }
    public string Modelname { get; set; }
    public string devName { get; set; }
    public string type { get; set; }

    public CommSetting commSetting { get; set; }
}

public class CommSetting
{
    public int portNo { get; set; }
    public bool useSSl { get; set; }
    public string password { get; set; }
}

[XmlRoot("Devices")]
public class DeviceCollection
{
    [XmlElement("dev")]
    public List<Device> Devices { get; set; }
}