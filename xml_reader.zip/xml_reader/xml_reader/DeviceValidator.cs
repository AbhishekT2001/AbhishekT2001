﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using xml_reader;

public class DeviceValidator
{
    public static void ValidateAndPrintDeviceDictionary(Dictionary<string, Device> deviceDictionary, string filePath)
    {
        for (int i = 0; i < deviceDictionary.Count; i++)
        {
            var kvp = deviceDictionary.ElementAt(i);
            // Validate each device and store the result in the validationResults dictionary
            Dictionary<string, string> deviceValidation = ValidateDevice(kvp.Value);

            // Print only if there are errors
            if (deviceValidation.Count >= 1)
            {
                PrintValidationResults(i + 1, kvp.Key, deviceValidation, kvp.Value);
            }
            else
            {
                showMenu.Menu(filePath);
            }
        }
    }

    private static void PrintValidationResults(int index, string serialNumber, Dictionary<string, string> validationErrors, Device device)
    {
        if (validationErrors.Count > 0)
        {
            Console.WriteLine($"Device index\t\t{index}");
            // Print errors dynamically
            PrintPropertiesWithErrors(device, validationErrors);
            Console.WriteLine();
        }
    }

    private static void PrintPropertiesWithErrors(object obj, Dictionary<string, string> validationErrors, string parentPropertyName = "")
    {
        foreach (var property in obj.GetType().GetProperties())
        {
            string propertyName = property.Name;
            string propertyValue = property.GetValue(obj)?.ToString() ?? "null";
            string fullPropertyName = string.IsNullOrEmpty(parentPropertyName) ? propertyName : $"{parentPropertyName}.{propertyName}";

            if (property.PropertyType.IsClass && property.PropertyType != typeof(string))
            {
                // Recursive call for nested properties (e.g., commSetting)
                PrintPropertiesWithErrors(property.GetValue(obj), validationErrors, fullPropertyName);
            }
            else
            {
                if (validationErrors.TryGetValue(fullPropertyName, out string errorMessage))
                {
                    Console.WriteLine($"{FormatPropertyName(fullPropertyName)}\t\t\t{errorMessage}");
                }
                else
                {
                    Console.WriteLine($"{FormatPropertyName(fullPropertyName)}\t\t\t{propertyValue}");
                }
            }
        }
    }


    private static string FormatPropertyName(string fullPropertyName)
    {
        // Remove the "commSetting." prefix from property names
        return fullPropertyName.Replace("commSetting.", "");
    }

    private static Dictionary<string, string> ValidateDevice(Device device)
    {
        Dictionary<string, string> validationErrors = new Dictionary<string, string>();

        // Check for errors and update the validation results
        if (string.IsNullOrWhiteSpace(device.SrNo))
        {
            validationErrors["SerialNumber"] = "Serial number is required";
        }
        if (!Regex.IsMatch(device.SrNo, @"^[a-zA-Z0-9]+$"))
        {
            validationErrors["SerialNumber"] = "Invalid format";
        }
        if (string.IsNullOrWhiteSpace(device.Address))
        {
            validationErrors["Address"] = "Address is required";
        }
        if (!Regex.IsMatch(device.Address, @"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$"))
        {
            validationErrors["Address"] = "Invalid format";
        }
        if (device.Address.Length > 15)
        {
            validationErrors["Address"] = "Address cannot exceed 15 characters";
        }
        if (device.devName.Length > 24)
        {
            validationErrors["DeviceName"] = "Device name is too long";
        }
        if (!Regex.IsMatch(device.devName, @"^[a-zA-Z0-9\s]+$"))
        {
            validationErrors["DeviceName"] = "Invalid format";
        }
        if (!Regex.IsMatch(device.Modelname, @"^[a-zA-Z0-9\s]+$"))
        {
            validationErrors["Modelname"] = "Invalid format";
        }
        if (device.Modelname.Length > 50)
        {
            validationErrors["Modelname"] = "Model name is too long"; 
        }
        if (device.type.Length <= 0)
        {
            validationErrors["Type"] = "Type is required";
        }


             //Validate commSetting
            if (device.commSetting == null)
            {
                validationErrors["CommSetting"] = "Communication settings are required";
            }
            else
            {
                // Validate sub-properties of commSetting
                if (device.commSetting.portNo <= 0)
                {
                    validationErrors["commsetting.PortNo"] = "Port number is required and must be greater than 0";
                }
                if (device.commSetting.useSSl != false && device.commSetting.useSSl != true)
                {
                validationErrors["commsetting.UseSSl"] = "UseSSL is required and must be true or false";
                }

            // Add more validations for commSetting properties as needed
            // For example:
            if (string.IsNullOrWhiteSpace(device.commSetting.password))
                {
                    validationErrors["commsetting.Password"] = "Password is required";
                }
                if (device.commSetting.password.Length < 1 || device.commSetting.password.Length > 64)
                {
                    validationErrors["commsetting.Password"] = "Password must be between 1 and 64 characters";
                }
                if (!Regex.IsMatch(device.commSetting.password, @"^[a-zA-Z0-9\s\#$%@!]+$"))
                {
                validationErrors["commsetting.Password"] = "Invalid format";
                }

            // You can add more specific validations based on your requirements
        }

        return validationErrors;
    }
}
