﻿using System;
using System.Collections.Generic;

public class Program
{
    public static void Main(string[] args)
    {
        string filePath = args[0];

        var deviceDictionary = XmlDeserializer.DeserializeXml(filePath);
        // Print device information

        //string searchSrNo = "Abc00000013";


        //var validationResults = DeviceValidator.ValidateDeviceDictionary(deviceDictionary);

        // Print validation results

        DeviceValidator.ValidateAndPrintDeviceDictionary(deviceDictionary, filePath);
        
    }
}