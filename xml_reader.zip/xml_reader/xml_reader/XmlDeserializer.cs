﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Serialization;

public class XmlDeserializer
{
    public static Dictionary<string, Device> DeserializeXml(string filePath)
    {
        XmlSerializer serializer = new XmlSerializer(typeof(DeviceCollection));
        using (FileStream fileStream = new FileStream(filePath, FileMode.Open))
        {
            DeviceCollection deviceCollection = (DeviceCollection)serializer.Deserialize(fileStream);
            Dictionary<string, Device> deviceDictionary = deviceCollection.Devices.ToDictionary(d => d.SrNo, d => d);
            return deviceDictionary;
        }
    }
}