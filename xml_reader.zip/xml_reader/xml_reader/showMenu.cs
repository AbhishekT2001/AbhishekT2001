﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace xml_reader
{
    public class showMenu
    {
        public static void Menu(string filePath)
        {
            Console.WriteLine("Please select an option: \n 1- to show all Devices \n 2- to search device by SerialNumber \n 3- to exit \n");
            string option = Console.ReadLine();

            var deviceDictionary = XmlDeserializer.DeserializeXml(filePath);

            if (option == "1")
            {
                PrintDevice.printDevice(deviceDictionary);
            }
            else if (option == "2")
            {
                Console.WriteLine("Enter Serial Number: ");
                string searchSrNo = Console.ReadLine();
                DevicePrinter.PrintSrNo(deviceDictionary, searchSrNo);
            }
            else if (option == "3")
            {
                Environment.Exit(0);
            }
            else
            {
                Console.WriteLine("Invalid option. Please try again.");
            }
        }
    }
}
