﻿using System.Collections.Generic;
using System;

public class DevicePrinter
{
    public static void PrintSrNo(Dictionary<string, Device> deviceDictionary, string searchSrNo)
    {
        if (deviceDictionary.TryGetValue(searchSrNo, out Device device))
        {
            Console.WriteLine($"SrNo: {device.SrNo}");
            Console.WriteLine($"Address: {device.Address}");
            Console.WriteLine($"Modelname: {device.Modelname}");
            Console.WriteLine($"devName: {device.devName}");
            Console.WriteLine($"Type: {device.type}");
            Console.WriteLine($"CommSetting: ");
            Console.WriteLine($"   PortNo: {device.commSetting.portNo}");
            Console.WriteLine($"   UseSSl: {device.commSetting.useSSl}");
            Console.WriteLine($"   Password: {device.commSetting.password}");
        }
        else
        {
            Console.WriteLine($"Device with SrNo '{searchSrNo}' not found.");
        }
    }
}