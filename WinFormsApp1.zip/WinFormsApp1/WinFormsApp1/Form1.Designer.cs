﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            BtnSelectSource = new Button();
            BtnSelectDestination = new Button();
            BtnAddToCopy = new Button();
            BtnCancelAll = new Button();
            dataGridView1 = new DataGridView();
            SourceColumn = new DataGridViewTextBoxColumn();
            DestinationColumn = new DataGridViewTextBoxColumn();
            ThreadNameColumn = new DataGridViewTextBoxColumn();
            StatusColumn = new DataGridViewTextBoxColumn();
            ProgressColumn = new DataGridViewTextBoxColumn();
            InfoColumn = new DataGridViewTextBoxColumn();
            CancelColumn = new DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // textBox1
            // 
            textBox1.Location = new Point(106, 36);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(492, 23);
            textBox1.TabIndex = 0;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(106, 65);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(492, 23);
            textBox2.TabIndex = 1;
            // 
            // BtnSelectSource
            // 
            BtnSelectSource.Location = new Point(624, 36);
            BtnSelectSource.Name = "BtnSelectSource";
            BtnSelectSource.Size = new Size(75, 23);
            BtnSelectSource.TabIndex = 2;
            BtnSelectSource.Text = "Browse";
            BtnSelectSource.UseVisualStyleBackColor = true;
            BtnSelectSource.Click += BtnSelectSource_Click;
            // 
            // BtnSelectDestination
            // 
            BtnSelectDestination.Location = new Point(624, 65);
            BtnSelectDestination.Name = "BtnSelectDestination";
            BtnSelectDestination.Size = new Size(75, 23);
            BtnSelectDestination.TabIndex = 3;
            BtnSelectDestination.Text = "Browse";
            BtnSelectDestination.UseVisualStyleBackColor = true;
            BtnSelectDestination.Click += BtnSelectDestination_Click;
            // 
            // BtnAddToCopy
            // 
            BtnAddToCopy.Location = new Point(106, 115);
            BtnAddToCopy.Name = "BtnAddToCopy";
            BtnAddToCopy.Size = new Size(91, 23);
            BtnAddToCopy.TabIndex = 4;
            BtnAddToCopy.Text = "Add to copy";
            BtnAddToCopy.UseVisualStyleBackColor = true;
            BtnAddToCopy.Click += BtnAddToCopy_Click;
            // 
            // BtnCancelAll
            // 
            BtnCancelAll.Location = new Point(281, 115);
            BtnCancelAll.Name = "BtnCancelAll";
            BtnCancelAll.Size = new Size(75, 23);
            BtnCancelAll.TabIndex = 5;
            BtnCancelAll.Text = "Cancel All";
            BtnCancelAll.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { SourceColumn, DestinationColumn, ThreadNameColumn, StatusColumn, ProgressColumn, InfoColumn, CancelColumn });
            dataGridView1.Location = new Point(29, 164);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.Size = new Size(740, 193);
            dataGridView1.TabIndex = 6;
            // 
            // SourceColumn
            // 
            SourceColumn.HeaderText = "SourceColumn";
            SourceColumn.Name = "SourceColumn";
            // 
            // DestinationColumn
            // 
            DestinationColumn.HeaderText = "DestinationColumn";
            DestinationColumn.Name = "DestinationColumn";
            // 
            // ThreadNameColumn
            // 
            ThreadNameColumn.HeaderText = "ThreadColumn";
            ThreadNameColumn.Name = "ThreadNameColumn";
            // 
            // StatusColumn
            // 
            StatusColumn.HeaderText = "StatusColumn";
            StatusColumn.Name = "StatusColumn";
            // 
            // ProgressColumn
            // 
            ProgressColumn.HeaderText = "ProgressColumn";
            ProgressColumn.Name = "ProgressColumn";
            // 
            // InfoColumn
            // 
            InfoColumn.HeaderText = "InfoColumn";
            InfoColumn.Name = "InfoColumn";
            // 
            // CancelColumn
            // 
            CancelColumn.HeaderText = "";
            CancelColumn.Name = "CancelColumn";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(dataGridView1);
            Controls.Add(BtnCancelAll);
            Controls.Add(BtnAddToCopy);
            Controls.Add(BtnSelectDestination);
            Controls.Add(BtnSelectSource);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox1;
        private TextBox textBox2;
        private Button BtnSelectSource;
        private Button BtnSelectDestination;
        private Button BtnAddToCopy;
        private Button BtnCancelAll;
        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn SourceColumn;
        private DataGridViewTextBoxColumn DestinationColumn;
        private DataGridViewTextBoxColumn ThreadNameColumn;
        private DataGridViewTextBoxColumn StatusColumn;
        private DataGridViewTextBoxColumn ProgressColumn;
        private DataGridViewTextBoxColumn InfoColumn;
        private DataGridViewTextBoxColumn CancelColumn;
    }
}
