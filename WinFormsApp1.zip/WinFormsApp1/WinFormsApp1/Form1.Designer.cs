﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            BtnSelectSource = new Button();
            BtnSelectDestination = new Button();
            BtnAddToCopy = new Button();
            BtnCancelAll = new Button();
            dataGridView1 = new DataGridView();
            SourceColumn = new DataGridViewTextBoxColumn();
            DestinationColumn = new DataGridViewTextBoxColumn();
            ThreadNameColumn = new DataGridViewTextBoxColumn();
            StatusColumn = new DataGridViewTextBoxColumn();
            ProgressColumn = new DataGridViewTextBoxColumn();
            InfoColumn = new DataGridViewTextBoxColumn();
            CancelColumn = new DataGridViewButtonColumn();
            label1 = new Label();
            label2 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox1.Location = new Point(106, 28);
            textBox1.Name = "textBox1";
            textBox1.ReadOnly = true;
            textBox1.Size = new Size(985, 27);
            textBox1.TabIndex = 0;
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBox2.Location = new Point(106, 64);
            textBox2.Name = "textBox2";
            textBox2.ReadOnly = true;
            textBox2.Size = new Size(985, 27);
            textBox2.TabIndex = 1;
            // 
            // BtnSelectSource
            // 
            BtnSelectSource.BackColor = SystemColors.AppWorkspace;
            BtnSelectSource.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BtnSelectSource.Location = new Point(1097, 28);
            BtnSelectSource.Name = "BtnSelectSource";
            BtnSelectSource.Size = new Size(75, 31);
            BtnSelectSource.TabIndex = 2;
            BtnSelectSource.Text = "Browse";
            BtnSelectSource.UseVisualStyleBackColor = false;
            BtnSelectSource.Click += BtnSelectSource_Click;
            // 
            // BtnSelectDestination
            // 
            BtnSelectDestination.BackColor = SystemColors.AppWorkspace;
            BtnSelectDestination.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BtnSelectDestination.Location = new Point(1097, 64);
            BtnSelectDestination.Name = "BtnSelectDestination";
            BtnSelectDestination.Size = new Size(75, 27);
            BtnSelectDestination.TabIndex = 3;
            BtnSelectDestination.Text = "Browse";
            BtnSelectDestination.UseVisualStyleBackColor = false;
            BtnSelectDestination.Click += BtnSelectDestination_Click;
            // 
            // BtnAddToCopy
            // 
            BtnAddToCopy.BackColor = SystemColors.Highlight;
            BtnAddToCopy.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BtnAddToCopy.Location = new Point(106, 97);
            BtnAddToCopy.Name = "BtnAddToCopy";
            BtnAddToCopy.Size = new Size(485, 41);
            BtnAddToCopy.TabIndex = 4;
            BtnAddToCopy.Text = "Add to copy";
            BtnAddToCopy.UseVisualStyleBackColor = false;
            BtnAddToCopy.Click += BtnAddToCopy_Click;
            // 
            // BtnCancelAll
            // 
            BtnCancelAll.BackColor = SystemColors.AppWorkspace;
            BtnCancelAll.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BtnCancelAll.Location = new Point(597, 97);
            BtnCancelAll.Name = "BtnCancelAll";
            BtnCancelAll.Size = new Size(494, 41);
            BtnCancelAll.TabIndex = 5;
            BtnCancelAll.Text = "Cancel All";
            BtnCancelAll.UseVisualStyleBackColor = false;
            BtnCancelAll.Click += BtnCancelAll_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { SourceColumn, DestinationColumn, ThreadNameColumn, StatusColumn, ProgressColumn, InfoColumn, CancelColumn });
            dataGridView1.Location = new Point(12, 164);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.Size = new Size(1160, 363);
            dataGridView1.TabIndex = 6;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // SourceColumn
            // 
            SourceColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            SourceColumn.HeaderText = "SourceColumn";
            SourceColumn.Name = "SourceColumn";
            SourceColumn.ReadOnly = true;
            SourceColumn.Width = 111;
            // 
            // DestinationColumn
            // 
            DestinationColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            DestinationColumn.HeaderText = "DestinationColumn";
            DestinationColumn.Name = "DestinationColumn";
            DestinationColumn.ReadOnly = true;
            DestinationColumn.Width = 135;
            // 
            // ThreadNameColumn
            // 
            ThreadNameColumn.HeaderText = "ThreadColumn";
            ThreadNameColumn.Name = "ThreadNameColumn";
            ThreadNameColumn.ReadOnly = true;
            // 
            // StatusColumn
            // 
            StatusColumn.HeaderText = "StatusColumn";
            StatusColumn.Name = "StatusColumn";
            StatusColumn.ReadOnly = true;
            // 
            // ProgressColumn
            // 
            ProgressColumn.HeaderText = "ProgressColumn";
            ProgressColumn.Name = "ProgressColumn";
            ProgressColumn.ReadOnly = true;
            // 
            // InfoColumn
            // 
            InfoColumn.HeaderText = "InfoColumn";
            InfoColumn.Name = "InfoColumn";
            InfoColumn.ReadOnly = true;
            // 
            // CancelColumn
            // 
            CancelColumn.HeaderText = "";
            CancelColumn.Name = "CancelColumn";
            CancelColumn.ReadOnly = true;
            CancelColumn.Resizable = DataGridViewTriState.True;
            CancelColumn.SortMode = DataGridViewColumnSortMode.Automatic;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(42, 32);
            label1.Name = "label1";
            label1.Size = new Size(61, 21);
            label1.TabIndex = 7;
            label1.Text = "Source";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(11, 66);
            label2.Name = "label2";
            label2.Size = new Size(93, 21);
            label2.TabIndex = 8;
            label2.Text = "Destination";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1184, 761);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dataGridView1);
            Controls.Add(BtnCancelAll);
            Controls.Add(BtnAddToCopy);
            Controls.Add(BtnSelectDestination);
            Controls.Add(BtnSelectSource);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            MinimumSize = new Size(1200, 800);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox1;
        private TextBox textBox2;
        private Button BtnSelectSource;
        private Button BtnSelectDestination;
        private Button BtnAddToCopy;
        private Button BtnCancelAll;
        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn SourceColumn;
        private DataGridViewTextBoxColumn DestinationColumn;
        private DataGridViewTextBoxColumn ThreadNameColumn;
        private DataGridViewTextBoxColumn StatusColumn;
        private DataGridViewTextBoxColumn ProgressColumn;
        private DataGridViewTextBoxColumn InfoColumn;
        private DataGridViewButtonColumn CancelColumn;
        private Label label1;
        private Label label2;
    }
}
