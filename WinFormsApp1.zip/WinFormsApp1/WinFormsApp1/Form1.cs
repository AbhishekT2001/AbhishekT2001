using System.ComponentModel;
using System.Configuration;
using System.Diagnostics;
using static WinFormsApp1.FileCopyManager;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        // Create a Queue to store the file copy processes
        private FileCopyManager fileCopyManager;
        private CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
        private bool isCancellationRequested = false;

        public Form1()
        {
            InitializeComponent();

            int workerCount = int.Parse(ConfigurationManager.AppSettings["CopyThreadCount"]);
            if (workerCount < 1 || workerCount > 100)
            {
                workerCount = 5;
                MessageBox.Show("Invalid thread count in config. Using default 5.");
            }

            // Initialize the FileCopyManager
            fileCopyManager = new FileCopyManager(workerCount, this.UpdateDisplay);

        }

        private void BtnSelectSource_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Multiselect = true;

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string[] fileNames = openFileDialog.FileNames;
                string concatenatedPaths = string.Join(", ", fileNames);
                textBox1.Text = concatenatedPaths;
            }
        }

        private void BtnSelectDestination_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();

            if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                textBox2.Text = folderBrowserDialog.SelectedPath;
            }
        }

        private void BtnAddToCopy_Click(object sender, EventArgs e)
        {
            // Retrieve the file paths from textbox1 and the destination folder path from textbox2
            string[] files = textBox1.Text.Split(new string[] { ", " }, StringSplitOptions.RemoveEmptyEntries);
            string destinationFolder = textBox2.Text;

            // Enqueue each file copy task into the taskQueue
            foreach (string file in files)
            {
                FileCopyTask fileCopyTask = new FileCopyTask(file, destinationFolder);
                fileCopyManager.EnqueueFiles(files, destinationFolder);
            }
            fileCopyManager.StartWorkers();
        }

        public void UpdateDisplay(CopyStatus status)
        {
            {
                dataGridView1.Invoke((Action)(() =>
                {
                    // Find the row with the corresponding source file
                    DataGridViewRow row = dataGridView1.Rows
                        .Cast<DataGridViewRow>()
                        .FirstOrDefault(r => r.Cells["SourceColumn"].Value?.ToString() == status.SourceFile);

                    if (row == null)
                    {
                        // Add a new row if not found
                        int rowIndex = dataGridView1.Rows.Add();
                        row = dataGridView1.Rows[rowIndex];

                        // Populate source and destination columns
                        row.Cells["SourceColumn"].Value = status.SourceFile;
                        row.Cells["DestinationColumn"].Value = status.DestFile;

                        // Add a cancel button
                        //DataGridViewButtonCell cancelButtonCell = new DataGridViewButtonCell();
                        //cancelButtonCell.Value = "Cancel";
                        //row.Cells["CancelColumn"] = cancelButtonCell;

                        //// Handle the button click event to cancel the task
                        //cancelButtonCell.Click += (sender, e) =>
                        //{
                        //    // Handle cancel button click (cancel the task)
                        //    // You may need to implement the logic to cancel the corresponding task
                        //    // For example, set a flag or use a CancellationToken
                        //};
                    }

                    // Update other columns
                    row.Cells["ThreadNameColumn"].Value = $"ThreadWorker{threadIndex}"; // Assuming thread name is set
                    row.Cells["StatusColumn"].Value = status.Status;
                    row.Cells["ProgressColumn"].Value = status.Progress + "%";
                    row.Cells["InfoColumn"].Value = status.Info;
                }));
            }
        }
    }



    public class FileCopyTask
    {
        public string SourceFile { get; set; }
        public string DestinationFolder { get; set; }

        public FileCopyTask(string sourceFile, string destinationFolder)
        {
            SourceFile = sourceFile;
            DestinationFolder = destinationFolder;
        }
    }
}