using System.ComponentModel;
using System.Configuration;
using static WinFormsApp1.FileCopyManager;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        // Create a Queue to store the file copy processes
        private FileCopyManager fileCopyManager;
        private CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
        private bool isCancellationRequested = false;
        private bool pauseWorkers = false;

        public Form1()
        {
            InitializeComponent();

            int workerCount = int.Parse(ConfigurationManager.AppSettings["CopyThreadCount"]!);
            if (workerCount < 1 || workerCount > 100)
            {
                workerCount = 5;
                MessageBox.Show("Invalid thread count in config. Using default 5.");
            }

            // Initialize the FileCopyManager
            fileCopyManager = new FileCopyManager(workerCount, this.UpdateDisplay);

        }

        private void BtnSelectSource_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Multiselect = true;

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string[] fileNames = openFileDialog.FileNames;
                string concatenatedPaths = string.Join(", ", fileNames);
                textBox1.Text = concatenatedPaths;
            }
        }

        private void BtnSelectDestination_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();

            if (folderBrowserDialog.ShowDialog() == DialogResult.OK)
            {
                textBox2.Text = folderBrowserDialog.SelectedPath;
            }
        }

        private void BtnAddToCopy_Click(object sender, EventArgs e)
        {
            // Retrieve the file paths from textbox1 and the destination folder path from textbox2
            string[] files = textBox1.Text.Split(new string[] { ", " }, StringSplitOptions.RemoveEmptyEntries);
            string destinationFolder = textBox2.Text;

            if (files.Length > 0 && Directory.Exists(destinationFolder))
            {
                // Enqueue each file copy task into the taskQueue
                foreach (string file in files)
                {
                    FileCopyTask fileCopyTask = new FileCopyTask(file, destinationFolder);
                    fileCopyManager.EnqueueFiles(files, destinationFolder);
                }
                fileCopyManager.StartWorkers();
            }
            else
            {
                MessageBox.Show("Invalid file or destination folder path.");
            }
        }

        public void UpdateDisplay(CopyStatus status)
        {
            if (dataGridView1.InvokeRequired)
            {
                if (!IsHandleCreated || IsDisposed)
                {
                    // Handle not created or form disposed, exit the method
                    return;
                }

                BeginInvoke(new Action(() => UpdateDisplay(status)));
                return;
            }

            // Continue with the rest of the method

            // Find the row with the corresponding source file
            DataGridViewRow row = dataGridView1.Rows
                .Cast<DataGridViewRow>()
                .FirstOrDefault(r => r.Cells["SourceColumn"].Value?.ToString() == status.SourceFile);

            if (row == null)
            {
                // Add a new row if not found
                int rowIndex = dataGridView1.Rows.Add();
                row = dataGridView1.Rows[rowIndex];

                // Populate source and destination columns
                row.Cells["SourceColumn"].Value = status.SourceFile;
                row.Cells["DestinationColumn"].Value = status.DestFile;
            }

            // Update other columns
            row.Cells["ThreadNameColumn"].Value = status.ThreadName;
            row.Cells["StatusColumn"].Value = status.Status;
            row.Cells["ProgressColumn"].Value = status.Progress + "%";
            row.Cells["InfoColumn"].Value = status.Info;

            // Set row color based on status
            switch (status.Status.ToLower())
            {
                case "copying":
                case "pending":
                    row.DefaultCellStyle.BackColor = Color.Yellow;
                    break;
                case "copied":
                    row.DefaultCellStyle.BackColor = Color.Green;
                    break;
                case "error":
                    row.DefaultCellStyle.BackColor = Color.Red;
                    break;
                default:
                    row.DefaultCellStyle.BackColor = Color.White; // Default color
                    break;
            }
        }


        private void BtnCancelAll_Click(object sender, EventArgs e)
        {
            fileCopyManager.PauseWorkers();

            // Ask for confirmation before canceling
            DialogResult result = MessageBox.Show("Are you sure you want to cancel all processes?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                // Cancel all workers
                fileCopyManager.CancelWorkers();
            }
            else
            {
                // Resume workers if the user chose not to cancel
               fileCopyManager.ResumeWorkers();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

    }

    public class FileCopyTask
    {
        public string SourceFile { get; }
        public string DestinationFolder { get; }

        public FileCopyTask(string sourceFile, string destinationFolder)
        {
            SourceFile = sourceFile;
            DestinationFolder = destinationFolder;
        }
    }
}