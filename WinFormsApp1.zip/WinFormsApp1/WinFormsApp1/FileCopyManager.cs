﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Threading;
using static WinFormsApp1.Form1;

namespace WinFormsApp1
{
    public class FileCopyManager
    {
        private Queue<FileCopyTask> processQueue = new Queue<FileCopyTask>();
        private BackgroundWorker[] workers;
        private Action<CopyStatus> updateDisplay;
        private int[] threadIndices;

        public FileCopyManager(int workerCount, Action<CopyStatus> updateDisplay)
        {
            this.updateDisplay = updateDisplay;

            // Initialize threadIndices array
            threadIndices = new int[workerCount];

            workers = new BackgroundWorker[workerCount];
            for (int i = 0; i < workerCount; i++)
            {
                BackgroundWorker worker = new BackgroundWorker();
                worker.WorkerReportsProgress = true;
                worker.DoWork += Worker_DoWork;
                worker.RunWorkerCompleted += Worker_RunWorkerCompleted;
                worker.ProgressChanged += Worker_ProgressChanged;

                // Set the thread index with the current index
                threadIndices[i] = i + 1;

                workers[i] = worker;
            }
        }

        public void EnqueueFiles(string[] files, string destinationPath)
        {
            foreach (string file in files)
            {
                processQueue.Enqueue(new FileCopyTask(file, destinationPath));
            }
        }

        public void StartWorkers()
        {
            foreach (BackgroundWorker worker in workers)
            {
                if (!worker.IsBusy && processQueue.Count > 0)
                {
                    FileCopyTask task = processQueue.Dequeue();
                    worker.RunWorkerAsync(task);
                }
            }
        }

        public void CancelWorkers()
        {
            foreach (BackgroundWorker worker in workers)
            {
                if (worker.IsBusy)
                {
                    worker.CancelAsync();
                }
            }
        }

        private void Worker_DoWork(object sender, DoWorkEventArgs e)
        {
            BackgroundWorker worker = sender as BackgroundWorker;
            FileCopyTask task = e.Argument as FileCopyTask;

            string sourceFile = task.SourceFile;
            string destinationPath = task.DestinationFolder;

            try
            {
                string destFile = Path.Combine(destinationPath, Path.GetFileName(sourceFile));
                int totalBytes = (int)new FileInfo(sourceFile).Length;
                int bytesCopied = 0;

                using (FileStream sourceStream = new FileStream(sourceFile, FileMode.Open, FileAccess.Read))
                using (FileStream destStream = new FileStream(destFile, FileMode.Create, FileAccess.Write))
                {
                    byte[] buffer = new byte[4096];
                    int bytesRead;

                    while ((bytesRead = sourceStream.Read(buffer, 0, buffer.Length)) > 0)
                    {
                        destStream.Write(buffer, 0, bytesRead);
                        bytesCopied += bytesRead;

                        int progress = (int)((double)bytesCopied / totalBytes * 100);
                        worker.ReportProgress(progress, new CopyStatus(sourceFile, destFile, "Copying", progress, ""));
                    }
                }

                worker.ReportProgress(100, new CopyStatus(sourceFile, destFile, "Copied", 100, ""));
            }
            catch (Exception ex)
            {
                worker.ReportProgress(0, new CopyStatus(sourceFile, "", "Error: " + ex.Message, 0, ex.Message));
            }
        }

        private void Worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            StartWorkers(); // Start another worker if there are more tasks
        }

        private void Worker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            if (e.UserState is CopyStatus status)
            {
                updateDisplay?.Invoke(status);
            }
        }

        public class CopyStatus
        {
            public string SourceFile { get; set; }
            public string DestFile { get; set; }
            public string Status { get; set; }
            public int Progress { get; set; }
            public string Info { get; set; }

            public CopyStatus(string sourceFile, string destFile, string status, int progress, string info)
            {
                SourceFile = sourceFile;
                DestFile = destFile;
                Status = status;
                Progress = progress;
                Info = info;
            }
        }
    }
}
